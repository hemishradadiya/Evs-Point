
import "bootstrap/dist/css/bootstrap.min.css";
import {
    MdAccountCircle,
    // MdSupervisorAccount,
    // MdSpeed,
    // MdOutlinePayment,
  
  
  } from "react-icons/md";
  import { Link } from "react-router-dom";
  

export default function Sidebar(){

  const logout = () => {
    localStorage.removeItem("token");
    window.location.href = "login";
   }  
  
    return(
        
    <div className="row grid-com">
      <div className="col-2 grid-left-com pt-5">
          <MdAccountCircle size={120} className="icon-color " />
          <h1>Admin</h1>
          <h6>admin123@gmail.com</h6>
          <hr/>
          <p>
          <Link to="/User"  className="links" >
              Users
            </Link>
            </p>
            <p>
          <Link to="/Owners"  className="links page-item" >
              Owners
            </Link>
            </p>
            <p>
          <Link to="/station"  className="links">
              Stations
            </Link>
            </p>
            <p>
          <Link to="/StationReq"  className="links">
              Stations Request
            </Link>
            </p>
            <p>
          <Link to="/UserHelpReq"  className="links">
          User Help Request
            </Link>
            </p>
            <p className="links">
          <Link to="/HelpReq"  className="links">
             Owner Help Requests
            </Link>
            </p>
          <hr />
          <button className="btn btn-success" onClick={logout}>
            Log Out
          </button>
        </div>
    </div>
    )
} 