import React, { useEffect, useState } from "react"
import { makeStyles } from '@material-ui/core/styles';
import {Table,TableBody,TableCell,TableContainer,TableHead,TableRow,Paper,Avatar,TableFooter,TablePagination} from '@material-ui/core';
import Sidebar from "./Sidebar";
import "../App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import {useNavigate } from "react-router-dom";
const useStyles = makeStyles((theme) => ({
  txt:{
    
  },
  table: {
    minWidth: 650,
  },
  tableContainer: {
      borderRadius: 15,
      margin: '10px 10px',
      maxWidth: 1550,
  
  },
  foot:{
    maxWidth: 1550
  },
  tableHeaderCell: {
      fontWeight: 'bold',
      backgroundColor: '#75c31e',
      color: theme.palette.getContrastText(theme.palette.primary.dark)
  },
  avatar: {
      backgroundColor: '#75c31e',
      color: theme.palette.getContrastText(theme.palette.primary.light)
  },
  name: {
      fontWeight: 'bold',
      // color: theme.palette.secondary.dark
      fontSize:15
  },
  h1:{
    marginTop:50
  },
  status: {
      fontWeight: 'bold',
      fontSize: '0.75rem',
      color: 'white',
      backgroundColor: 'grey',
      borderRadius: 8,
      padding: '3px 10px',
      display: 'inline-block'
  },
  btn:{
    width:70,
    height:45,
    fontWeight: 'bold',
    backgroundColor: 'blue',
    color: theme.palette.getContrastText(theme.palette.primary.dark),
    borderWidth:0,
    borderRadius:10,
    marginRight:10
  },
  btn1:{
    width:70,
    height:45,
    fontWeight: 'bold',
    backgroundColor: 'red',
    color: theme.palette.getContrastText(theme.palette.primary.dark),
    borderWidth:0,
    borderRadius:10,
  }
}));
export default function BasicTable() {

    const [users, setUsers] = useState([])
    const classes = useStyles();
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(5);
    const handleChangePage = (event, newPage) => {
      setPage(newPage);
    };
    
    const downloadReport = async () => {
      try {
        const response = await axios.post("http://localhost:4000/owner/download-report", {});
        const file = new Blob([response.data], { type: "text/csv" });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(file);
        link.download = "owner-report.csv";
        link.click();
      } catch (error) {
        console.error("Error downloading report:", error);
      }
    };

    const handleChangeRowsPerPage = (event) => {
      setRowsPerPage(+event.target.value);
      setPage(0);
    };

  const fetchData = () => {
 fetch("http://localhost:4000/owner.json")
      .then(response => {
        return response.json()
      })
      .then(data => {
        setUsers(data)
      })
  }

  useEffect(() => {
    fetchData()
  }, [])
  const navigate = useNavigate();
  return (
    <div>
      <Sidebar></Sidebar>
        <div className="col-10 grid-right-com">
        <div className="d-flex justify-content-center align-items-center  mb-3"> 
         <h1 className={classes.h1}>Owners Information</h1>
         <button className="rounded-pill btn-success" onClick={downloadReport}>Report<span class="iconify" data-icon="material-symbols:download"></span></button>
         </div>
    <TableContainer component={Paper} className={classes.tableContainer}>
      <Table className={classes.table} aria-label="simple table">
        <TableHead>
          <TableRow>
            
            <TableCell className={classes.tableHeaderCell}></TableCell>
            <TableCell className={classes.tableHeaderCell}>ID</TableCell>
            <TableCell className={classes.tableHeaderCell}>First Name</TableCell>
            <TableCell className={classes.tableHeaderCell}>Last Name</TableCell>
            <TableCell className={classes.tableHeaderCell}>Email</TableCell>
            <TableCell className={classes.tableHeaderCell}>ContactNo</TableCell>
            <TableCell className={classes.tableHeaderCell}>Action</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {users.map((row) => (
            <TableRow
              key={row._id}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                <Avatar alt={row.ownerName} src='.' className={classes.avatar} />
              </TableCell>
              <TableCell className={classes.name}>{row._id}</TableCell>
              <TableCell className={classes.name}>{row.firstName}</TableCell>
              <TableCell className={classes.name}>{row.lastName}</TableCell>
              <TableCell className={classes.name}>{row.email}</TableCell>
              <TableCell className={classes.name}>{row.contactNo}</TableCell>
              <TableCell><button type="button" className={classes.btn} onClick={()=>{navigate('/OwnerOperation',{state:{row}})}}>Edit</button>
                        <button className={classes.btn1} type="button" onClick={()=>{

                         axios.delete(`http://localhost:4000/owner/delete/${row._id}`)
                          .then((result)=>{
                            window.location.href ='/Owners';
                          })
                          .catch(error => {
                            console.log(error);
                          })}}

                      >Delete</button></TableCell>
                               </TableRow>
                             ))}
                           </TableBody>

                         </Table>
                         <TableFooter className={classes.foot}>
                           <TablePagination

            rowsPerPageOptions={[5, 10, 15]}
            component="div"
            count={users.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
        />
        </TableFooter>
    </TableContainer>
    </div>
    </div>
  );
}