--> you have to run "npm install" for installing node modules

--> if you want to run  this project you simply run "npm start"
	and after that your project will run on the "http://localhost:3000"
