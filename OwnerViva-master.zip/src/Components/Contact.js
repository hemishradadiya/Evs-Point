/* eslint-disable no-unused-vars */
import React ,{useState,useEffect} from "react";

import { IoMdAddCircle, IoMdHelpCircle } from "react-icons/io";
import Sidebar from "./Sidebar";


const Contact = () => {
 return (
  <>
      <Sidebar />
         <div className="col-xs-6 col-sm-8 col-lg-10 grid-right-com">
          <h2 className="history">
            <IoMdHelpCircle className="icon-color" />
            Help
          </h2>
        </div>
  
      <div className="col-10 grid-right-com">

      <section>
      <div>
        <div className="d-flex justify-content-center align-items-center  mb-3">
        <div className="p-3 bg help ">
                  <div className="d-flex justify-content-center align-items-center  mb-3">
                    <h4 className="text-right bold">Help-Center</h4>
                  </div>  
                 
                   <div className="row mt-2 d-flex justify-content-center align-items-center mb-3">
                    <div className="col-md-6">
                      <label htmlFor="floatingInput" className="bold">Name:</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="enter Your Name"
                      />
                    </div>
                  </div>
                  <div className="row mt-2 d-flex justify-content-center align-items-center  mb-3">
                    <div className="col-md-6">
                      <label htmlFor="floatingInput" className="bold">Email:</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="enter Your Email" 
                      />
                    </div>
                  </div>
                  <div className="row mt-2 d-flex justify-content-center align-items-center  mb-3">
                    <div className="col-md-6">
                      <label htmlFor="floatingInput" className="bold">Describe Your issue:</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="enter issue" 
                      />
                    </div>
                  </div>
                  <div className="row mt-2 d-flex justify-content-center align-items-center  mb-3">
                    <div className="col-md-6">
                      <label htmlFor="floatingInput" className="bold">Message:</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="enter Your Message"  
                      />
                    </div>
                  </div>
                  <div className="mt-5 text-center">
                    <button
                      className="btn btn-success profile-button"
                      type="button"
                    >
                      Send Message
                    </button>
                  </div>
                </div>
        </div>
        </div>
      </section>
    </div>
      
  </>
  );
};

export default Contact;
