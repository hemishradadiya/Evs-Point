import React, { useState, useEffect } from "react";
import {
  MdOutlinePayment,
} from "react-icons/md";
import { Link, useLocation, useNavigate } from "react-router-dom";
import Sidebar from "./Sidebar";

const Payment = () => {

  const location = useLocation();
  const navigate = useNavigate();

  return (
    <>
      <Sidebar />
      <div className="col-10 grid-right-com">
        <h2 className="history">
          <MdOutlinePayment className="icon-color" />
          OrderDetails
        </h2>
        <div className="d-flex justify-content-center align-items-center  mb-3">
          <div className="p-3 orderDetails">
            <div className="d-flex justify-content-center align-items-center">
              <h1 className="title1">Order Details</h1>
            </div>

            <div className="d-flex justify-content-center align-items-center ">
              <div className="detailsbox">

                <div className="d-flex justify-content-center align-items-center  mb-3">
                  <div className="stationbox">
                    <div className="mt-2 text-center">
                      <h1 className=" white">{location.state.row.StationName}</h1>
                    </div>
                  </div>
                </div>

                <div class="row mx-4">
                  <div class="col">
                    <p className="bold" >Customer Name:</p>
                  </div>
                  <div class="col">
                    <p className="">{location.state.row.FirstName}{" "}{location.state.row.LastName}</p>
                  </div>
                </div>

                <div class="row mx-4">
                  <div class="col">
                    <p className="bold">ContactNo:</p>
                  </div>
                  <div class="col">
                    <p className="">{location.state.row.ContactNo}</p>
                  </div>
                </div>

                <div class="row mx-4">
                  <div class="col">
                    <p className="bold ">Email:</p>
                  </div>
                  <div class="col">
                    <p className="">{location.state.row.Email}</p>
                  </div>
                </div>

                <div class="row mx-4">
                  <div class="col">
                    <p className="bold ">City:</p>
                  </div>
                  <div class="col">
                    <p className="">{location.state.row.City}</p>
                  </div>
                </div>

                <div class="row mx-4">
                  <div class="col">
                    <p className="bold">State:</p>
                  </div>
                  <div class="col">
                    <p className="">{location.state.row.State}</p>
                  </div>
                </div>

                <div class="row mx-4">
                  <div class="col">
                    <p className="bold">Car:</p>
                  </div>
                  <div class="col">
                    <p className="">{location.state.row.Car}</p>
                  </div>
                </div>

                <div class="row mx-4">
                  <div class="col">
                    <p className="bold">Selected Plug:</p>
                  </div>
                  <div class="col">
                    <p className="">{location.state.row.Plug}</p>
                  </div>
                </div>

                <div class="row mx-4">
                  <div class="col">
                    <p className="bold">Date:</p>
                  </div>
                  <div class="col">
                    <p className="">{location.state.row.Date.slice(0, 10)}</p>
                  </div>
                </div>

                <div class="row mx-4">
                  <div class="col">
                    <p className="bold">Time:</p>
                  </div>
                  <div class="col">
                    <p className="">{location.state.row.Time}</p>
                  </div>
                </div>

                <div class="row mx-4">
                  <div class="col">
                    <p className="bold">Payment:</p>
                  </div>
                  <div class="col">
                    <p className="">{location.state.row.Payment}</p>
                  </div>
                </div>

              </div>
            </div>


            <div className="mt-5 text-center">
              <button className="btn btn-success subbtn" type="button" onClick={() => { navigate('/history') }}> Go Back </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Payment;
