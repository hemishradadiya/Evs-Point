
import {  MdSpeed } from "react-icons/md";
import { IoMdAddCircle } from "react-icons/io";
import { Link } from "react-router-dom";
import Sidebar from "./Sidebar";

const Deshboard = () => {

  return (
      <>
      <Sidebar />
      <div className="dashboard-info">
        <div className="col-xs-6 col-sm-8 col-lg-10 grid-right-com">
          <h2 className="history">
            <MdSpeed className="icon-color" />
            Deshboard
          </h2>
        </div>
      <div>
        <button
          type="button"
          className="btn btn-success position-absolute top-30 end-0 btn5">
          <IoMdAddCircle className="icon" size={40} />
          <Link to="/station" className="addlink">
            Add Station
          </Link>
        </button>
      </div>
      <div className="dashboard-menu-box">
      <div className="menu">
        <div className="col-6">
        <div className="grid-right-com1 dashboard-box">
          <Link to="/history" className="history1 history-link">
            My Orders
          </Link>
        </div>
        </div>
        <div className="col-6">
        <div className="grid-right-com2 dashboard-box">
          <Link to="/Mystation" className="history2 history-link">
            My station
          </Link>
        </div>
        </div>
      </div>
      <div className="menu">
      <div className="col-6">
        <div className="grid-right-com3 dashboard-box">
          <Link to="/help" className="history3 history-link">
            Help
          </Link>
        </div>
        </div>
        <div className="col-6">
        <div className="grid-right-com4 dashboard-box">
          <Link to="/Stationlist" className="history4 history-link">
            Station List
          </Link>
        </div>
        </div>
        </div>
        </div>
      </div>
    </>
  );
};

export default Deshboard;
