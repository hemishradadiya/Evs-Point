import React ,{useState, useEffect} from "react";
import { IoMdHelpCircle } from "react-icons/io";
import Sidebar from "./Sidebar";


const Contact = () => {

  const [Name,setName] = useState("")
  const [nameerror,setNameError] = useState("")

  const [Email,setMail] = useState("")
  const [emailerror,setEmailError] = useState("")

  const [Issue,setIssue] = useState("")
  const [issueerror,setIssueError] = useState("")
  
  const [Message,setMessage] = useState("")
  const [messageerror,setMessageerror] = useState("")

  useEffect( () => {
    const token = localStorage.getItem("token");
    if (token === null) {
      window.location.href = "login";
    } else {
      fetch("http://localhost:4000/ownerauth", {
        headers: new Headers({ Authorization: "Bearer " + token }),
      })
        .then((res) => res.json())
        .then((data) => {
          setName(data.firstName +" "+ data.lastName)
          setMail(data.email);
        });
    }
  },[]);

  function saveDataget() {
    if (Name.length === 0) {
      setNameError("*Name is requied");
    } else if (Email.length === 0) {
      setEmailError("*Email is requied");
    }else if (Issue.length === 0) {
      setIssueError("*issue is requied");
    }else if (Message.length === 0) {
      setMessageerror("*message is requied");
    } else {
      let data = { Name, Email,Issue,Message };
      fetch("http://localhost:4000/ownerhelp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization:
            "Bearer eyJhbGciOiJIUzI1NiIffsInR5cCI6IkpXVCJ1.eyJ1c2VySWQiOiI2MWJjNWRlMzEyODRlN2ZjYTM3OGMwMzAiLCJffpYXQiOjE2Mzk3MzQ3NTV2.bHygAffPHN6AUUldKvEyvLLdtWvjGYPdaxjtrPnYw88Vo",
          Accept: "*/*",
          "Accept-Encoding": "gzip, deflate, br",
        },
        body: JSON.stringify(data),
      })
        .then((resp) => resp.json())
        .then((result) => {   
             console.log("help message send successful");
             window.location.href = "helpSuccess";         
        });
    }
  }
  

 return ( 
  <>
   <Sidebar />

         <div className="col-xs-6 col-sm-8 col-lg-10 grid-right-com">
          <h2 className="history">
            <IoMdHelpCircle  className="icon-color" />
            Help
          </h2>
          
        </div>
  
      <div className="col-10 grid-right-com">

      <section>
      <div>
        <div className="d-flex justify-content-center align-items-center  mb-3">
        <div className="p-3 bg help ">
                  <div className="d-flex justify-content-center align-items-center  mb-3">
                    <h4 className="text-right bold">Owner Help-Center</h4>
                  </div>  
                 
                   <div className="row mt-2 d-flex justify-content-center align-items-center mb-3">
                    <div className="col-md-6">
                      <label htmlFor="floatingInput" className="bold">Name:</label>
                      <input
                        type="text"
                        className="form-control"
                        defaultValue={Name}
                        onChange={(e) => {
                          setName(e.target.value);
                        }}
                      />
                      <p className="err">{nameerror}</p>
                    </div>
                  </div>
                  <div className="row mt-2 d-flex justify-content-center align-items-center  mb-3">
                    <div className="col-md-6">
                      <label htmlFor="floatingInput" className="bold">Email:</label>
                      <input
                        type="text"
                        className="form-control"
                        defaultValue={Email} 
                        onChange={(e) => {
                          setMail(e.target.value);
                        }}
                      />
                      <p className="err">{emailerror}</p>
                    </div>
                  </div>
                  <div className="row mt-2 d-flex justify-content-center align-items-center  mb-3">
                    <div className="col-md-6">
                      <label htmlFor="floatingInput" className="bold">Describe Your issue:</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="enter issue" 
                        onChange={(e) => {
                          setIssue(e.target.value);
                        }}
                      />
                      <p className="err">{issueerror}</p>
                    </div>
                  </div>
                  <div className="row mt-2 d-flex justify-content-center align-items-center  mb-3">
                    <div className="col-md-6">
                      <label htmlFor="floatingInput" className="bold">Message:</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="enter Your Message" 
                        onChange={(e) => {
                          setMessage(e.target.value);
                        }} 
                      />
                      <p className="err">{messageerror}</p>
                    </div>
                  </div>
                  <div className="mt-5 text-center">
                    <button
                      className="btn btn-success profile-button"
                      type="button"
                      onClick={saveDataget}
                    >
                      Send Message
                    </button>
                  </div>
                </div>
        </div>
        </div>
      </section>
    </div>
      
  </>
  );
};

export default Contact;
