import React ,{useState,useEffect} from "react";
import {
  MdAccountCircle,
  MdSupervisorAccount,
} from "react-icons/md";
import Sidebar from "./Sidebar";

const Profile = () => {
  const [firstName, setFirstName] = useState("Loading");
  const [lastName, setLastName] = useState("Loading");
  const [contactNo, setContactNo] = useState("Loading");
  const [email, setEmail] = useState("Loading");


  useEffect(async () => {
    const token = await localStorage.getItem("token");
    if (token === null) {
      window.location.href = "login";
    } else {
      fetch("http://localhost:4000/ownerauth", {
        headers: new Headers({ Authorization: "Bearer " + token }),
      })
        .then((res) => res.json())
        .then((data) => {
          console.log(token);
          setFirstName(data.firstName);
          setLastName(data.lastName);
          setContactNo(data.contactNo);
          setEmail(data.email);
        });
    }
  }, []);
  return(
    <>
    <Sidebar />
        <div className="col-10 grid-right-com">
          <h2 className="history">
            <MdSupervisorAccount className="icon-color" />
            Profile
          </h2>
          <div className="container rounded mt-5 mb-5 ">
            <div className="row">
              <div className="col-md-12 border-right">
                <div className="p-3">
                  <div className="d-flex justify-content-center align-items-center  mb-3">
                    <h4 className="text-right">Basic Information</h4>
                  </div>  
                  {/* <div className="row mt-2">
                    <div className="col-md-6 form-floating">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="first name"
                        value=""
                        id="floatingInput"
                      />
                      <label for="floatingInput">First Name</label>
                    </div>
                    <div className="col-md-6 form-floating">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="last name"
                        value=""
                        id="floatingInput"
                      />
                      <label for="floatingInput">Last name</label>
                    </div>
                  </div> */}
                   <div className="row mt-2">
                    <div className="col-md-6">
                      <label htmlFor="floatingInput">first Name</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="enter first Name"
                        value={firstName}
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="floatingInput">last Name</label>
                      <input
                        type="text"
                        className="form-control"
                        value={lastName}
                        placeholder="enter last Name"
                      />
                    </div>
                  </div>
                  <div className="row mt-2">
                    <div className="col-md-6">
                      <label htmlFor="floatingInput">Mobile Number</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="enter phone number"
                        value={contactNo}
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="floatingInput">Address</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="enter address"
                      />
                    
                    </div>
                  </div>
                  <div className="row mt-2">
                    <div className="col-md-6">
                      <label htmlFor="floatingInput">Email ID</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="enter email id"
                        value={email}
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="floatingInput">Gender</label>
                      <select className="form-select" id="floatingSelect" aria-label="Floating label select example">
                        <option defaultValue>--select gender--</option>
                        <option value="1">Male</option>
                        <option value="2">Female</option>
                        <option value="3">Other</option>
                      </select>
                    </div>
                  </div>
                  <div className="row mt-3">
                    <div className="col-md-6">
                      <label htmlFor="floatingInput">Country</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="country"
                        defaultValue="India"
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="floatingInput">State</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="state"
                      />
                    </div>
                  </div>
                  <div className="mt-5 text-center">
                    <button
                      className="btn btn-success profile-button"
                      type="button"
                    >
                      Save Profile
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </>
  )
};

export default Profile;
