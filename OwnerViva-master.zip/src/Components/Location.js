import React,{Component} from "react";
import { HiLocationMarker, HiOutlineLogout } from "react-icons/hi";
import GoogleMapReact from 'google-map-react';
import Sidebar from "./Sidebar";
const AnyReactComponent = ({ text }) => <div>{text}</div>;
class Profile extends Component {
  static defaultProps = {
    center: {
      lat: 21.1702,
      lng: 72.8311
    },
    zoom: 12
  };

  render() {
  return (
    <>
      <Sidebar />
        <div className="col-10 grid-right-com">
          <h2 className="history">
            <HiLocationMarker className="icon-color" />
            Location
          </h2>
          <div style={{ height: '100vh', width: '100%' }}>
        <GoogleMapReact
          bootstrapURLKeys={{ key: 'AIzaSyAPxVr83wbDkDHrd9WYDb93J6vQ316_4TA'}}
          defaultCenter={this.props.center}
          defaultZoom={this.props.zoom}
        >
          <AnyReactComponent
            lat={59.955413}
            lng={30.337844}
            text="My Marker"
          />
          </GoogleMapReact>
        {/* <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3777152.2976585915!2d69.08323468625602!3d22.40547917112727!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3959051f5f0ef795%3A0x861bd887ed54522e!2sGujarat!5e0!3m2!1sen!2sin!4v1678168739768!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="true" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> */}

      </div>
        </div>
      </>
  );
  }
};

export default Profile;
