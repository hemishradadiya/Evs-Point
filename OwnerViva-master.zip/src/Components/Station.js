import React, { useState, useEffect } from "react";
import { IoMdAddCircle } from "react-icons/io";
import { Row } from "react-bootstrap";
import Sidebar from "./Sidebar";
import axios from "axios";



const Station = () => {
  const [id, setId] = useState("")
  const [name, setName] = useState("")

  const [data, setData] = useState({
    image: "",
    ownerName: "",
    StationName: "",
    ContactNo: "",
    address: "",
    city: "",
    state: "",
    openingTime: "",
    closeTime: "",
    AdharCardNo: "",
    pincode: "",
    Plug: "",
  });

  const handleChange = (name) => (e) => {
    let value = name === "image" ? e.target.files[0] : e.target.value;
    setData({ ...data, [name]: value });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (data.ContactNo.length === 0) {
        alert("*Contact No is requied");
      } else if (data.address.length === 0) {
        alert("*Address is requied");
      } else if (data.AdharCardNo.length === 0) {
        alert("*AdharCard No is requied");
      } else if (data.AdharCardNo.length !== 12) {
        alert("*AdharCard No Must be 12 character");
      } else if (data.Plug.length === 0) {
        alert("*Please Select Plug Type");
      } else if (data.image === null) {
        alert("*Please Upload Station Image");
      } else {

        const formData = new FormData();

        formData.append("image", data.image);
        formData.append("ownerId", id);
        formData.append("ownerName", name);
        formData.append("StationName", data.StationName);
        formData.append("ContactNo", data.ContactNo);
        formData.append("address", data.address);
        formData.append("pincode", data.pincode);
        formData.append("city", data.city);
        formData.append("state", data.state);
        formData.append("openingTime", data.openingTime);
        formData.append("closeTime", data.closeTime);
        formData.append("Plug", data.Plug);
        formData.append("AdharCardNo", data.AdharCardNo);

        await axios.post(`http://localhost:4000/addStationRequest`, formData)
          .then((resp) => {
            // if (resp.headers['content-type'] === 'application/json') {
            console.log(resp)
            return resp.status;
            // }
          })
          .then((result) => {
            console.log(result);
            (result === 200) ? window.location.href = "request_Succcess" : console.log("not success");
          });
      }
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token === null) {
      window.location.href = "login";
    } else {
      fetch("http://localhost:4000/ownerauth", {
        headers: new Headers({ Authorization: "Bearer " + token }),
      })
        .then((res) => res.json())
        .then((data) => {
          setId(data.ownerId)
          setName(data.firstName + " " + data.lastName)
        });
    }
  }, []);


  return (
    <>
      <Sidebar />
      <div className="col-10 grid-right-com ">
        <h2 className="history">
          <IoMdAddCircle className="icon-color" />
          Add Station
        </h2>

        <div className="d-flex justify-content-center align-items-center  mb-3">
          <div className="p-3 bg addstation ">
            <div className="d-flex justify-content-center align-items-center  mb-3">
              <h4 className="text-right bold title">
                Send Request For Add New-Station
              </h4>
            </div>
            <Row className="mb-3">
              <div className="col-md-4">
                <label htmlFor="floatingInput" className="bold">
                  ownerName:
                </label>
                <input
                  type="text"
                  defaultValue={name}
                  className="form-control"

                  onChange={handleChange("ownerName")}
                />

              </div>
              <div className="col-md-4">
                <label htmlFor="floatingInput" className="bold">
                  StationName:
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="enter Your StationName"
                  onChange={handleChange("StationName")}
                />
              </div>
              <div className="col-md-4">
                <label htmlFor="floatingInput" className="bold">
                  ContactNo:
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="enter Your ContactNo"
                  onChange={handleChange("ContactNo")}
                />
              </div>
            </Row>
            <Row className="mb-3">
              <div className="col-md-4">
                <label htmlFor="floatingInput" className="bold">
                  openingTime:
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="enter Your openingTime"
                  onChange={handleChange("openingTime")}
                />
              </div>
              <div className="col-md-4">
                <label htmlFor="floatingInput" className="bold">
                  closeTime:
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="enter Your closeTime"
                  onChange={handleChange("closeTime")}
                />
              </div>
              <div className="col-md-4">
                <label htmlFor="floatingInput" className="bold">
                  Address:
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="enter Your Address"
                  onChange={handleChange("address")}
                />

              </div>
            </Row>
            <Row className="mb-3">
              <div className="col-md-4">
                <label htmlFor="floatingInput" className="bold">
                  pincode:
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="enter Your pincode"
                  onChange={handleChange("pincode")}
                />
              </div>
              <div className="col-md-4">
                <label htmlFor="floatingInput" className="bold">
                  state:
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="enter state"
                  onChange={handleChange("state")}
                />
              </div>

              <div className="col-md-4">
                <label htmlFor="floatingInput" className="bold">
                  city
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="enter Your city"
                  onChange={handleChange("city")}
                />
              </div>
            </Row>
            <Row className="mb-3">
              <div className="col-md-4">
                <label htmlFor="floatingInput" className="bold">
                  AdharCardNo
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="enter Your AdharCardNo"
                  onChange={handleChange("AdharCardNo")}
                />

              </div>
              <div className="col-md-4">
                <label htmlFor="floatingInput" className="bold">
                  Plugs:
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter Station Plugs 'Like: Chomed-1,Type-2'"
                  onChange={handleChange("Plug")}
                />
                {/* <select className="form-select" id="floatingSelect" aria-label="Floating label select example" onChange={handleChange("Plug")}>
                        <option defaultValue>--select Plug--</option>
                        <option value="1">CCS (Combined Charging System)</option>
                        <option value="2">CHAdeMo Charger</option>
                        <option value="3">GB/T Charger</option>
                </select> */}
              </div>
              <div className="col-md-4">
                <label htmlFor="floatingInput" className="bold">
                  Select Your Station Image
                </label>
                <input
                  className="form-control select"
                  type="file"
                  name="image"
                  accept=".jpg,.jpeg,.png"
                  required
                  onChange={handleChange("image")}
                />
              </div>
            </Row>

            <p>{data.ownerId}</p>
            <div className="mt-5 text-center">
              <button
                className="btn btn-success profile-button subbtn"
                type="button"
                onClick={handleSubmit}
              >
                Submit Request
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Station;