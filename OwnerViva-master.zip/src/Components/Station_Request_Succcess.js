import React  from "react";

import { IoMdAddCircle, IoMdHelpCircle } from "react-icons/io";
import Sidebar from "./Sidebar";


const Request_Succcess = () => {
  
  function goback() {       
            window.location.href = "deshboard";
  }
  
 return (
  <>
   <Sidebar />
         <div className="col-xs-6 col-sm-8 col-lg-10 grid-right-com">
          <h2 className="history">
            <IoMdHelpCircle  className="icon-color" />
            Your request
          </h2>
          
        </div>
      
  
      <div className="col-10 grid-right-com">
     
      <section className="text-center">
          <img src={require('../Container/images/download.png')}  className="image"/>
      </section>
      <h1 className="mt-5 text-center msg">Your Request for New Station</h1>
      <h1 className="mt-5 text-center msg">is Successfully Send</h1>
      <div className="mt-5 text-center">
            <button
              className="btn btn-success btngoback "
              type="button" 
              onClick={goback}
            >
              Go Back
            </button>
        </div>
      </div>
  </>
  );
};

export default Request_Succcess;
