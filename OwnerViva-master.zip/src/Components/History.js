import React, { useState, useEffect } from "react";
import { AiOutlineHistory } from "react-icons/ai";
import { Link, useNavigate } from "react-router-dom";
import { Form, Button, Col, Row, InputGroup } from "react-bootstrap";
import Sidebar from "./Sidebar";
//import Cardcom from '../UI Com/Cardcom';

const History = () => {
  const [id, setId] = useState()
  const [user, setUsers] = useState([])


  const token = localStorage.getItem("token");
  if (token === null) {
    window.location.href = "login";
  } else {
    fetch("http://localhost:4000/ownerauth", {
      headers: new Headers({ Authorization: "Bearer " + token }),
    })
      .then((res) => res.json())
      .then((data) => {
        setId(data.ownerId)
      })
  }



  useEffect(async () => {
    console.log(id);
    fetch(`http://localhost:4000/user/bookingData/${id}`)
      .then(response => {
        return response.json()
      })
      .then(data => {
        setUsers(data)
      })
  }, [id])


  const navigate = useNavigate();

  return (
    <>
      <Sidebar />
      <div className="col-10 grid-right-com">
        <h2 className="history">
          <AiOutlineHistory className="icon-color" />
          History
        </h2>
        <div>
          {user.map((row) => (
            <div key={row._id}>
              <div className="d-flex justify-content-center align-items-center  mb-3">

                <div className="p-3 bg addstation">
                  <div className="row">
                    <div className="col">
                      <h1 className="StationName1">{row.StationName}</h1>
                    </div>
                    <div className="col">
                      <button className="btn3" onClick={() => { navigate('/orderDetails', { state: { row } }) }}>
                        View Details
                      </button>
                    </div>
                  </div>

                  <div className="underline"></div>
                  <div className="row">
                    <div className="col">
                      <p className="bold">Customer Name:</p>
                    </div>
                    <div className="col">
                      <p className="">{row.FirstName}{" "}{row.LastName}</p>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col">
                      <p className="bold">ContactNo:</p>
                    </div>
                    <div className="col">
                      <p className="">{row.ContactNo}</p>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col">
                      <p className="bold">Plug:</p>
                    </div>
                    <div className="col">
                      <p className="">{row.Plug}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default History;
