import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Row } from "react-bootstrap";
import Sidebar from "./Sidebar";

const Station = () => {
  const [id, setId] = useState("")
  const [data, setData] = useState([])

  useEffect(async () => {
    const token = localStorage.getItem("token");
    if (token === null) {
      window.location.href = "login";
    } else {
      await fetch("http://localhost:4000/ownerauth", {
        headers: new Headers({ Authorization: "Bearer " + token }),
      })
        .then((res) => res.json())
        .then((data) => {
          setId(data.ownerId)
        })
    }
  }, [setId])


  useEffect(() => {
    if (id) {
      fetch(`http://localhost:4000/OwnerStation/${id}`)
        .then(response => response.json())
        .then(data => {
          setData(data);
        })
    }
  }, [id])

  const navigate = useNavigate();

  return (
    <>
      <Sidebar />
      <div className="col-10 grid-right-com ">
        <h2 className="history">
          <div className="d-flex justify-content-center align-items-center  mb-3">
            <h2 className="text-right bold ">My station</h2>
          </div>
        </h2>
        {data.map((row) => (
          <div key={row._id}>
            <div className="d-flex justify-content-center align-items-center  mb-3">

              <div className="p-3 addstation">

                <div className="row">
                  <div className="col-md-8">
                    <h1 className="StationName1">{row.StationName}</h1>
                  </div>
                  <div className="col-md-4">
                    <button className="btn3 " onClick={() => { navigate('/stationDetails', { state: { row } }) }}>
                      View Details
                    </button>
                  </div>
                </div>
                <div className="underline"></div>
                <div className="row">
                  <div className="col">
                    <p className="bold">Owner Name:</p>
                  </div>
                  <div className="col">
                    <p className="">{row.FirstName}{" "}{row.ownerName}</p>
                  </div>
                </div>
                <div className="row">
                  <div className="col">
                    <p className="bold">ContactNo:</p>
                  </div>
                  <div className="col">
                    <p className="">{row.ContactNo}</p>
                  </div>
                </div>
                <div className="row">
                  <div className="col">
                    <p className="bold">Available Plugs:</p>
                  </div>
                  <div className="col">
                    <p className="">{row.Plug1}{"  "}{row.Plug2}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default Station;
