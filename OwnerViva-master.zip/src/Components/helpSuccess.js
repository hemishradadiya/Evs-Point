// import React, { useState, useEffect } from "react";
import { IoMdHelpCircle } from "react-icons/io";

import Sidebar from "./Sidebar";

const Contact = () => {

  function goback() {
    window.location.href = "deshboard";
  }

  // useEffect(async () => {
  //   const token = await localStorage.getItem("token");
  //   if (token === null) {
  //     window.location.href = "login";
  //   } else {
  //     fetch("http://localhost:4000/ownerauth", {
  //       headers: new Headers({ Authorization: "Bearer " + token }),
  //     })
  //       .then((res) => res.json())
  //       .then((data) => {
  //         //   console.log(data)
  //         console.log(token);
  //         setFirstName(data.firstName);
  //         setLastName(data.lastName);
  //         setContactNo(data.contactNo);
  //         setEmail(data.email);
  //       });
  //   }
  // }, []);

  // const logout = () => {
  //   localStorage.removeItem("token");
  //   window.location.href = "login";
  // };

  return (
    <>
      <div>
        <Sidebar />
        <div className="col-xs-6 col-sm-8 col-lg-10 grid-right-com">
          <h2 className="history">
            <IoMdHelpCircle className="icon-color" />
            Help
          </h2>
        </div>
      </div>

      <div className="col-10 grid-right-com">
      <section className="text-center">
          <img src={require('../Container/images/download.png')}  className="image" alt="download"/>
      </section>
        <h1 className="mt-5 text-center msg">Your Message Successfully Send</h1>
        <div className="mt-5 text-center">
          <button
            className="btn btn-success btngoback "
            type="button"
            onClick={goback}
          >
            Go Back
          </button>
        </div>
      </div>
    </>
  );
};

export default Contact;
