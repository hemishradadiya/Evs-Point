import React, { useState, useEffect } from "react";
import {
  MdOutlinePayment,
} from "react-icons/md";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Row } from "react-bootstrap";
import Sidebar from "./Sidebar";

const StationDetails = () => {
  const [firstName, setFirstName] = useState("Loading")
  const [lastName, setLastName] = useState("Loading")
  const [email, setEmail] = useState("Loading")

  useEffect(async () => {
    const token = await localStorage.getItem("token");
    if (token === null) {
      window.location.href = "login";
    } else {
      fetch("http://localhost:4000/ownerauth", {
        headers: new Headers({ Authorization: "Bearer " + token }),
      })
        .then((res) => res.json())
        .then((data) => {
          //   console.log(data)
          console.log(token);
          setFirstName(data.firstName);
          setLastName(data.lastName);
          setEmail(data.email);
        });
    }
  }, []);

  const location = useLocation();
  const navigate = useNavigate();

  return (
    <>
      <Sidebar />
      <div className="col-10 grid-right-com">
        <h2 className="history">
          <MdOutlinePayment className="icon-color" />
          OrderDetails
        </h2>
        <div className="d-flex justify-content-center align-items-center  mb-3">
          <div className="p-3 orderDetails ">
            <div className="d-flex justify-content-center align-items-center">
              <h1 className="">Station Details</h1>
            </div>

            <div className="d-flex justify-content-center align-items-center  mb-3">
              <div className="detailsbox">

                <div className="d-flex justify-content-center align-items-center  mb-3">
                  <div className="stationbox">
                    <div className="text-center">
                      <h1 className="white">{location.state.row.StationName}</h1>
                    </div>
                  </div>
                </div>

                <div className="p-4 ">
                  <div className="row">
                    <div className="col">
                      <p className="bold" >Owner Name:</p>
                    </div>
                    <div className="col">
                      <p className="">{location.state.row.ownerName}</p>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col">
                      <p className="bold margin">ContactNo:</p>
                    </div>
                    <div className="col">
                      <p className="">{location.state.row.ContactNo}</p>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col">
                      <p className="bold margin">Address:</p>
                    </div>
                    <div className="col">
                      <p className="">{location.state.row.address}</p>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col">
                      <p className="bold margin">City:</p>
                    </div>
                    <div className="col">
                      <p class="">{location.state.row.city}</p>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col">
                      <p className="bold ">State:</p>
                    </div>
                    <div className="col">
                      <p class="">{location.state.row.state}</p>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col">
                      <p className="bold">Available Plug:</p>
                    </div>
                    <div className="col">
                      <p className="">{location.state.row.Plug1}{"  "}{location.state.row.Plug2}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>


            <div className="mt-5 text-center">
              <button
                className="btn btn-success profile-button subbtn"
                type="button"
                onClick={() => { navigate('/Mystation') }}
              >
                Go Back
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default StationDetails;
