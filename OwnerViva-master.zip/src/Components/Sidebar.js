import React, { useState, useEffect } from "react";
import {
  MdAccountCircle,
  MdSupervisorAccount,
  MdSpeed,
  MdOutlinePayment,
} from "react-icons/md";
import { AiOutlineHistory } from "react-icons/ai";
import { IoMdAddCircle, IoMdHelpCircle } from "react-icons/io";
import { HiLocationMarker, HiOutlineLogout } from "react-icons/hi";
import { Link } from "react-router-dom";

export default function Sidebar() {
  const [firstName, setFirstName] = useState("no");
  const [lastName, setLastName] = useState("user");
  const [contactNo, setContactNo] = useState("0000000000");
  const [email, setEmail] = useState("NaN");

  useEffect(async () => {
    const token = await localStorage.getItem("token");
    if (token === null) {
      window.location.href = "login";
    } else {
      fetch("http://localhost:4000/ownerauth", {
        headers: new Headers({ Authorization: "Bearer " + token }),
      })
        .then((res) => res.json())
        .then((data) => {
          console.log(token);
          setFirstName(data.firstName);
          setLastName(data.lastName);
          setContactNo(data.contactNo);
          setEmail(data.email);
        });
    }
  }, []);

  const logout = () => {
    localStorage.removeItem("token");
    window.location.href = "login";
  };

  return (
    <>
    <div className="sidebar">
      <div className="row grid-com">
        <div className="col-sm-4 col-md-3 col-lg-2 grid-left-com pt-2">
          <MdAccountCircle size={120} className="icon-color" />
          <h2>
            {firstName} {lastName}
          </h2>
          <h6>{email}</h6>
          <hr />
            <div className="link-component">
              <p className="links">
                <MdSpeed />
                <Link to="/deshboard" className="links">
                  Dashboard
                </Link>
              </p>

              <p className="links">
                <MdSupervisorAccount />
                <Link to="/Profile" className="links">
                  My profile
                </Link>
              </p>

              <p className="links"> 
                <AiOutlineHistory />
                <Link to="/history" className="links">
                  History
                </Link>
              </p>
              <p className="links">
                <IoMdAddCircle />
                <Link to="/station" className="links">
                  Add Station
                </Link>
              </p>
              <p className="links">
                <MdOutlinePayment />
                <Link to="/ShowStationRequest" className="links">
                  Station Request
                </Link>
              </p>
              <p className="links">
                <HiLocationMarker />
                <Link to="/location" className="links">
                  My Location
                </Link>
              </p>
              <p className="links">
                <IoMdHelpCircle />
                <Link to="/help" className="links">
                  Help
                </Link>
              </p>
            </div>

          <hr />
          <button className="btn btn-success" onClick={logout}>
            <HiOutlineLogout />
            Log Out
          </button>
        </div>
      </div>
      </div>
    </>
  );
}
