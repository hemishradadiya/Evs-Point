import React, { useState, useEffect } from "react";

import { Link, useNavigate } from "react-router-dom";
import { Row } from "react-bootstrap";
import Sidebar from "./Sidebar";

const Stationlist = () => {
  const [firstName, setFirstName] = useState("Loading")
  const [lastName, setLastName] = useState("Loading")
  const [email, setEmail] = useState("Loading")
  const [user, setUsers] = useState([])
  useEffect(async () => {
    const token = await localStorage.getItem("token");
    if (token === null) {
      window.location.href = "login";
    } else {
      fetch("http://localhost:4000/ownerauth", {
        headers: new Headers({ Authorization: "Bearer " + token }),
      })
        .then((res) => res.json())
        .then((data) => {
          //   console.log(data)
          console.log(token);
          setFirstName(data.firstName);
          setLastName(data.lastName);
          setEmail(data.email);
        })
        .then(
          fetch("http://localhost:4000/station")
            .then(response => {
              return response.json()
            })
            .then(data => {
              setUsers(data)
            })
        )
    }
  }, []);

  const navigate = useNavigate();

  return (
    <>
      <Sidebar />
      <div className="col-10 grid-right-com">
        <h2 className="history">
          Stationlist
        </h2>
        {/* <Cardcom>
            {history}
          </Cardcom> */}
        <div>
          {user.map((row) => (
            <div key={row._id}>
              <div className="d-flex justify-content-center align-items-center  mb-3">

                <div className="p-3 addstation">

                  <Row className="align-items-center">
                    <div className="col">
                      <div className="d-flex">
                        <img src={row.Image} className="image1" /></div>
                    </div>
                    <div className="col-md-5">
                      <h1 className="StationName1">{row.StationName}</h1>
                    </div>
                    <div className="col-md-3">
                      <button className="btn3 " onClick={() => { navigate('/stationDetails', { state: { row } }) }}>
                        View Details
                      </button>
                    </div>
                  </Row>
                  
                  <div className="underline"></div>
                    <div className="p-3">
                        <div className="row">
                          <div className="col">
                            <p className="bold">Owner Name:</p>
                          </div>
                          <div className="col">
                            <p class="">{row.FirstName}{" "}{row.ownerName}</p>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col">
                            <p className="bold">ContactNo:</p>
                          </div>
                          <div className="col">
                            <p className="">{row.ContactNo}</p>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col">
                            <p className="bold">Available Plugs:</p>
                          </div>
                          <div className="col">
                            <p className="">{row.Plug1}{"  "}{row.Plug2}</p>
                          </div>
                        </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Stationlist;
