import React, { useState, useEffect, useRef } from "react";
import signinpage from "../../images/signinpage.png";
import logo from "../../images/logo.png";
import { FaMobileAlt } from "react-icons/fa";
import { Link, Navigate } from "react-router-dom";
import { FaCar } from "react-icons/fa"
import $ from 'jquery';

import axios from "axios";

const ResetPass = () => {

  const [mobile, setMobile] = useState("");
  const [otp, setOtp] = useState(["", "", "", ""]);
  const inputRefs = [useRef(null), useRef(null), useRef(null), useRef(null)];
  const [password, setpassword] = useState("");
  const [confirmPassword, setconfirmPassword] = useState("");
  const [passShow, setPassShow] = useState(false);


  const SaveDataget = () => {
    if (mobile.length !== 10) {
      alert("please enter valid number");
    } else {
      alert("send OTP into database");
      axios.post(`http://localhost:4000/sendOtp`, {
        mobileno: mobile
      })
        .then(response => console.log(response.data))
        .catch(error => console.error(error));

      $(document).ready(function () {
        $('.otp-field').removeClass('hide');
      });
    }
  }

  const handleInputChange = (index, event) => {
    const value = event.target.value;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value.length === 1 && index < inputRefs.length - 1) {
      inputRefs[index + 1].current.focus();
    }
  };

  let newOtp = otp.join('');



  const handlesubmit = () => {
    if (mobile.length !== 10) {
      alert("please enter valid number");
    } else if (newOtp.length !== 4) {
      alert("please enter valid OTP")
    } else {
      axios.post(`http://localhost:4000/owner/VerifyOtp`, {
        mobileno: mobile,
        ownerOtp: newOtp
      })
        .then(res => res.status)
        .then(status => {
          if (status === 200) {
            alert("OTP successfully Verified")
            $(document).ready(function () {
              $('.resetPassComponents').removeClass('hide');
              $('.otpComponent').addClass('hide');
            });
          }
        })
        .catch(error => {
          setOtp(["","","",""])
          alert("Something Went Wrong !! \nPlease try again!")
          console.error(error)
        });
    }
  }

  const handlePass = ()=>{
    if(password.length === 0 && confirmPassword.length === 0 ){
      alert("Please Enter Password")
    }
    else if(password !== confirmPassword){
      alert("Password & ConfirmPassWord are not Same ")
      setpassword("");
      setconfirmPassword("")
    }else{
      axios.put(`http://localhost:4000/owner/update`, {
        password: password,
        confirmPassword: confirmPassword,
        contactNo: mobile
      })
      .then(res => res.status)
      .then(status => {
        if (status === 200) {
          alert("Password Set Successfully")
          window.location.href = "login";
        }
      })
      .catch(error => {
        alert("Something Went Wrong !! \nPlease try again!")
        console.error(error)
      });
    }
  }

  return (
    <>
      <div className="container-fluid main-back">
        <div className="container main-bg">
          <div className="side-image"></div>
          <div className="form-background"></div>
          <img
            src={logo}
            alt="logo"
            width="150px"
            height="39.87px"
            className="ima1"
          />
          <div className="row">
            <div className="col-xs-6 col-sm-8 col-lg-6 login-left ">
              <img src={signinpage} alt="page" className="img-fluid ima" />
            </div>
            
            <div className="col-xs-6 col-sm-4 col-lg-6 login-right">
              <div aria-disabled="true">
                <h2 className="p-3">Reset Password</h2>

                {/* otp components */}
                <div className="otpComponent">
                <form className="form" >
                  <div className="p-3 form-input">
                    <FaMobileAlt />
                    <input
                      type="tel"
                      name="phone"
                      placeholder="Enter Your Number"
                      value={mobile}
                      onChange={(e) => {
                        setMobile(e.target.value);
                      }}
                    />
                    <button type="button" className="btn btn-success otpbtn" onClick={SaveDataget}>Send</button>
                  </div>
                  <div className="otp-field hide">
                    <label style={{}}> Enter OTP : </label>
                    {otp.map((value, index) => (
                      <input
                        key={index}
                        type="text"
                        value={value}
                        maxLength={1}
                        onChange={(event) => handleInputChange(index, event)}
                        ref={inputRefs[index]}
                      />
                    ))}
                  </div>
                </form>
                <button
                  type="button"
                  className="btn1 d-grid gap-2 col-7 mx-auto mb-4 mt-4"
                  onClick={handlesubmit}
                  >
                  Submit
                </button>
                  <Link to="/register">Create new Account?</Link>
              </div>

              {/* reset pass conponent */}
                <div className="resetPassComponents hide">
                  <form className="form">
                    <div className="p-3 form-input">
                      <input
                        type={passShow ? "text" : "password"}
                        placeholder=" Enter New Password"
                        value={password}
                        onChange={(e) => {
                          setpassword(e.target.value);
                        }}
                      />
                    </div>
                    <div className="p-3 form-input">
                      <input
                        type={passShow ? "text" : "password"}
                        placeholder="Confirm Password"
                        value={confirmPassword}
                        onChange={(e) => {
                          setconfirmPassword(e.target.value);
                        }}
                      />
                    </div>
                    <div className="">
                    <input
                      type="checkbox"
                      onChange={(e) => {
                        setPassShow(!passShow);
                      }}
                    />
                    <label>Show password</label>
                  </div>
                  </form>
                  <button
                    type="button"
                    className="btn1 d-grid gap-2 col-7 mx-auto mb-4 mt-4"
                    onClick={handlePass} >
                    Submit
                  </button>
                </div>
                </div>
              </div>
          </div>
          
        </div>
      </div>
    </>
  );
};

export default ResetPass;
