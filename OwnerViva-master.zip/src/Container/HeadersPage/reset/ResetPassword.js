import React, { useState } from "react";
import { Link } from "react-router-dom";
import logo from "../../images/logo.png";
import { FaCar } from "react-icons/fa"
import signuppage from "../../images/signuppage.png";
import axios from "axios";

const ResetPassword = () => {

  const [password, setpassword] = useState("");
  const [confirmPassword, setconfirmPassword] = useState("");
  const [passShow, setPassShow] = useState(false);


  const handlesubmit = ()=>{
    if(password.length === 0 && confirmPassword.length === 0 ){
      alert("Please Enter Password")
    }
    else if(password !== confirmPassword){
      alert("Password & ConfirmPassWord are not Same ")
      setpassword("");
      setconfirmPassword("")
    }else{
      axios.post(`http://localhost:4000/owner/update`, {
        password: password,
      })
    }
  }
  return (
    <>
      <div className="container-fluid main-back">
        <div className="container main-bg">
          <div className="side-image"></div>
          <div className="form-background"></div>
          <img
            src={logo}
            alt="logo"
            width="150px"
            height="39.87px"
            className="ima1"
          />
          <div className="row">
            <div className="col-xs-6 col-sm-8 col-lg-6 login-left ">
              <img src={signuppage} alt="page" className="img-fluid ima" />
            </div>
            <div className="col-xs-6 col-sm-4 col-lg-6 login-right">
              <div aria-disabled="true">
                <h2 className="p-3">Reset Password</h2>
                <form className="form" >
                <div className="p-3 form-input">
                    <input
                      type={passShow ? "text" : "password"}
                      placeholder=" Enter New Password"
                      value={password}
                      onChange={(e) => {
                        setpassword(e.target.value);
                      }}
                    />
                  </div>
                  <div className="p-3 form-input">
                    <input
                      type={passShow ? "text" : "password"}
                      placeholder="Confirm Password"
                      value={confirmPassword}
                      onChange={(e) => {
                        setconfirmPassword(e.target.value);
                      }}
                    />
                  </div>
                  <div className="">
                    <input
                      type="checkbox"
                      onChange={(e) => {
                        setPassShow(!passShow);
                      }}
                    />
                    <label>Show password</label>
                  </div>
                </form>
                <button
                  type="button"
                  className="btn1 d-grid gap-2 col-7 mx-auto mb-4 mt-5"
                  onClick={handlesubmit}
                >
                  Submit
                </button>
              </div>
              <Link to="/register">Create new Account?</Link>
            </div>
          </div>
          <div className="container core mt-5">
            <div className="d-inline-flex">
              <div className="col-6">
                <p><FaCar />  Electric vehicles support environmental justice</p>
                <p><FaCar />  Clean air commitment</p>
              </div>
              <div className="col-6">
                <p><FaCar />  EVs help your community achieve climate change goals</p>
                <p><FaCar />  EV charging increases property value</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ResetPassword;
