const express = require("express");
require("dotenv").config();
const mongoose = require("mongoose");
var AWS = require("aws-sdk");
const router = express.Router();
require("../models/otp");
const OTP = mongoose.model("otp");
const User = mongoose.model('User')
const jwt = require("jsonwebtoken");
const jwtKey =
  "eyJhbGciOiJIUzI1NiIffsInR5cCI6IkpXVCJ1.eyJ1c2VySWQiOiI2MWJjNWRlMzEyODRlN2ZjYTM3OGMwMzAiLCJffpYXQiOjE2Mzk3MzQ3NTV2.bHygAffPHN6AUUldKvEyvLLdtWvjGYPdaxjtrPnYw88Vo";

router.post('/sendOtp', async (req, res) => {
  const  phone  = req.body.mobileno;
  console.log(phone)
  const otp = Math.floor(1000 + Math.random() * 9000);
  try {
    const otpDoc = await OTP.findOneAndUpdate({Phone:phone},{$set:{otp: otp}},{upsert: true, new: true});
    await otpDoc.save();
    res.send("otp is saved in the database");
  } catch (err) {
    res.status(500).json(err.message);
  }
});

//ownerotp
router.post('/owner/VerifyOtp', async (req, res)=>{
  try {
    const owner = await OTP.findOne({
      Phone: req.body.mobileno
    });
    
    if (!owner) {
      res.send("Mobile Number not found");
    } else {
      const otp = req.body.ownerOtp;
      console.log(otp)
      const dbOtp = owner.otp;
    
      if (dbOtp == otp) {
        const token = jwt.sign({ ownerId: owner._id }, jwtKey);
        res.status(200).json({ token });
      } else {
        res.status(401).json("Wrong OTP");
      }
    }
  } catch (err) {
    res.status(500).json(err.message);
  }
  });

// user otp
router.post("/VerifyOtp", async (req, res) => {
  try {
  const user = await OTP.findOne({
     Phone: req.body.Phone
  });
  const otp = req.body.otp 
  const dbOtp = user.otp
  if (!user) {
    res.send("Mobile Number are not Found");
  } else {    
   
    if(dbOtp === otp){
      const token = jwt.sign({ userId: user._id }, jwtKey); 
      res.status(200).json({ token });       
      
    }else{
        res.status(401).json("Wrong OTP");
       }
  }
} catch (err) {
  res.status(500).json(err.message);
}
});

router.put("/ResendOtp/:Phone",async (req, res) => {
  const Phone = req.params.Phone;
  var params = {
    Message: YOUR_MESSAGE,
    PhoneNumber: Phone,
    MessageAttributes: {
      "AWS.SNS.SMS.SenderID": {
        DataType: "String",
        StringValue: "hello",
      },
      "AWS.SNS.SMS.SMSType": {
        DataType: "String",
        StringValue: "Transactional",
      },
    },
  };

  var publishTextPromise = new AWS.SNS({ apiVersion: "2010-03-31" })
    .publish(params)
    .promise();

  publishTextPromise
    .then(function (data) {
      // console.log(data)
      res.end(JSON.stringify({ MessageID: data.MessageId, OTP: otp }));
    })
    .catch(function (err) {
      res.end(JSON.stringify({ Error: err }));
    });
  try {
    const userOtp = await OTP.findOneAndUpdate({Phone:Phone},{$set:{otp: otp}},{new: true,upsert: true});
    userOtp.save();
    res.send("otp is save in database");
  } catch (err) {

    res.status(500).json(err.message);
  }
});


module.exports = router;
