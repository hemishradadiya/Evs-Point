const express = require('express')
const mongoose = require('mongoose')
const cloudinary = require("../utils/cloudinary");
const upload = require("../utils/multer");
const router = express.Router();
require("../models/StationRequest")
const StationRequest = mongoose.model('StationRequest')

router.get('/stationRequestData',(req,res)=>{
   StationRequest.find().then((data)=>{
           res.status(200).json(data);
    })
})
router.get('/stationRequest/:ownerId', async (req,res)=>{     
   try{  
         const ownerid = req.params.ownerId;
         if(ownerid === undefined){
            return res.send("id is not found")
         }     
         console.log(ownerid)
         const station = await StationRequest.find({ownerId: ownerid});
         console.log(station)
         res.status(200).json(station);
      }
   catch(err)
     {
         throw err
     }
})
   


router.post('/addStationRequest', upload.single("image") ,async (req,res)=>{
      if(!req.file){
         console.log(req.body)
      }
      const result = await cloudinary.uploader.upload(req.file.path);
      
       const image= result.secure_url
       const { ownerId,ownerName, StationName,ContactNo,address,city,state,pincode,openingTime,closeTime,Plug,AdharCardNo} = req.body;   
       try{
       const station = new StationRequest({ownerId,ownerName, StationName,ContactNo,address,city,state,pincode,openingTime,closeTime,image,Plug,AdharCardNo}); 
       station.save();
       res.send({station})
    }catch(err){
      return res.status(422).send(err.message)
    }
})

// router.post("/addStationRequest", upload.single("image"), async (req, res) => {
//    try {
//       console.log(req.body)
//       req.file = req.file || {};
//       const filePath = req.file.path;
//      // Upload image to Cloudinary
//      const result = await cloudinary.uploader.upload(filePath);
 
//      // Save URL to database
//      const user = await user.findById(req.body.userId);
//      user.profileImageUrl = result.secure_url;
//      await user.save();
 
//      res.status(200).json({
//        success: true,
//        message: "Image uploaded successfully",
//        imageUrl: result.secure_url,
//      });
//    } catch (error) {
//      console.log(error);
//      res.status(500).json({
//        success: false,
//        message: "Internal server error",
//      });
//    }
//  });

router.delete(`/StationRequest/delete/:id`, async(req, res) => {
   try {
      const stdreqID = req.params.id
      if (!stdreqID) {1
         return res.status(404).send({
            message: "Station-Request not found with id  " + req.params.id
          });
      }
      console.log("delete success")
      let deletedata = await StationRequest.deleteOne({_id: stdreqID});
      res.send(deletedata)   
   } catch (error) { 
      throw error 
   }
})

// router.delete('/StationRequest/delete/:id', (req, res) => {
//    const id = req.params.id;

//    StationRequest.deleteOne({ _id: id}, (err, result) => {
//        if (err) {
//            res.status(500).send({ error: "Error deleting data" });
//        } else {
//            res.send({ message: "Data deleted successfully" });
//        }
//    });
// });
module.exports= router